<?php $__env->startSection('title', 'Manage Pickup Requests'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
    <li class="breadcrumb-item active">Pickup Requests</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-4">
    <h3 class="fw-bold mb-1">Pickup Requests Log</h3>
    <p class="text-muted small mb-0">System-wide monitoring of NGO pickup requests and fulfillment statuses.</p>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>Requested Item</th>
                        <th>Claiming NGO</th>
                        <th>Donor Restaurant</th>
                        <th>Scheduled Time</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td class="fw-bold text-dark"><?php echo e($req->foodDonation->food_name ?? 'Item'); ?></td>
                            <td><?php echo e($req->ngo->ngo_name ?? 'NGO'); ?></td>
                            <td><?php echo e($req->foodDonation->restaurant->restaurant_name ?? 'Restaurant'); ?></td>
                            <td class="small text-muted"><?php echo e($req->pickup_time ? $req->pickup_time->format('M d, Y H:i') : '-'); ?></td>
                            <td><span class="badge badge-<?php echo e(strtolower($req->status)); ?>"><?php echo e(ucfirst($req->status)); ?></span></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="mt-3">
            <?php echo e($requests->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\FoodWasteRescue\resources\views/admin/requests.blade.php ENDPATH**/ ?>