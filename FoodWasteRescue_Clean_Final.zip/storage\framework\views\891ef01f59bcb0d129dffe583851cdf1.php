Hello <?php echo e($userName); ?>,

Good news! Your FoodWasteRescue account has been approved by the admin. You can now log in to your account and use the platform.

Your account type: <?php echo e($accountType); ?>


Log in here: <?php echo e($loginUrl); ?>


Thank you for joining FoodWasteRescue!

Regards,
FoodWasteRescue Team
<?php /**PATH C:\xampp\htdocs\FoodWasteRescue\resources\views/emails/account_approved_text.blade.php ENDPATH**/ ?>