<?php $__env->startSection('title', 'My Food Donations'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('restaurant.dashboard')); ?>">Dashboard</a></li>
    <li class="breadcrumb-item active">My Food Donations</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h3 class="fw-bold mb-1">My Food Donations</h3>
        <p class="text-muted small mb-0">View, update, or remove your listed surplus food donations.</p>
    </div>
    <a href="<?php echo e(route('restaurant.donations.create')); ?>" class="btn btn-primary">
        <i class="fas fa-plus-circle me-1"></i> Add New Donation
    </a>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover align-middle" id="donationsTable">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>Food Item</th>
                        <th>Category</th>
                        <th>Type</th>
                        <th>Quantity</th>
                        <th>Cooked Time</th>
                        <th>Expiry Time</th>
                        <th>Status</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $donations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td class="fw-bold text-dark">
                                <?php echo e($d->food_name); ?>

                                <?php if($d->image): ?>
                                    <i class="fas fa-image text-muted ms-1" title="Has Image"></i>
                                <?php endif; ?>
                            </td>
                            <td><span class="badge bg-secondary"><?php echo e($d->category); ?></span></td>
                            <td><span class="badge bg-light text-dark border"><?php echo e($d->food_type); ?></span></td>
                            <td class="fw-semibold"><?php echo e($d->quantity); ?> <?php echo e($d->unit); ?></td>
                            <td class="small text-muted"><?php echo e($d->cooked_time ? $d->cooked_time->format('M d, H:i') : '-'); ?></td>
                            <td class="small text-muted"><?php echo e($d->expiry_time ? $d->expiry_time->format('M d, H:i') : '-'); ?></td>
                            <td><span class="badge badge-<?php echo e(strtolower($d->status)); ?>"><?php echo e(ucfirst($d->status)); ?></span></td>
                            <td class="text-end">
                                <a href="<?php echo e(route('restaurant.donations.edit', $d->id)); ?>" class="btn btn-sm btn-outline-primary me-1" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <form id="delete-donation-<?php echo e($d->id); ?>" action="<?php echo e(route('restaurant.donations.destroy', $d->id)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="button" class="btn btn-sm btn-outline-danger" onclick="confirmDelete('delete-donation-<?php echo e($d->id); ?>')" title="Delete">
                                        <i class="fas fa-trash-alt"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="9">
                                <div class="text-center py-5">
                                    <i class="fas fa-box-open fa-3x text-muted mb-3 opacity-50"></i>
                                    <h5 class="fw-bold text-dark mb-1">No Donations Found</h5>
                                    <p class="text-muted small">You haven't added any surplus food donations yet.</p>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="mt-3">
            <?php echo e($donations->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function() {
        var table = $('#donationsTable');
        if (table.length && table.find('tbody tr').length > 0 && table.find('tbody tr td[colspan]').length === 0) {
            table.DataTable({
                paging: false,
                info: false,
                searching: true,
                ordering: true,
                columnDefs: [
                    { orderable: false, targets: [-1] }
                ]
            });
        }
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\FoodWasteRescue\resources\views/restaurant/donations/index.blade.php ENDPATH**/ ?>