<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['request']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['request']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $status = $request->status;
    $isRejected = in_array($status, ['rejected', 'cancelled']);

    $stages = [
        'pending' => ['label' => 'Requested', 'icon' => 'fa-clipboard-list'],
        'accepted' => ['label' => 'Accepted', 'icon' => 'fa-check-circle'],
        'out_for_pickup' => ['label' => 'Out for Pickup', 'icon' => 'fa-truck'],
        'handover_confirmed' => ['label' => 'Handover Confirmed', 'icon' => 'fa-qrcode'],
        'completed' => ['label' => 'Completed', 'icon' => 'fa-box-check'],
    ];

    $stageOrder = ['pending', 'accepted', 'out_for_pickup', 'handover_confirmed', 'completed'];

    // Map 'picked' to 'handover_confirmed'
    $currentKey = ($status === 'picked') ? 'handover_confirmed' : $status;
    $currentIndex = array_search($currentKey, $stageOrder);
    if ($currentIndex === false && !$isRejected) {
        $currentIndex = 0;
    }
?>

<div class="stepper-wrapper mb-3 py-2 px-1">
    <?php if($isRejected): ?>
        <div class="alert alert-danger py-2 px-3 mb-0 d-flex align-items-center gap-2 rounded-3 small">
            <i class="fas fa-times-circle fa-lg"></i>
            <div>
                <strong>Request <?php echo e(ucfirst($status)); ?>:</strong>
                <span class="text-muted"><?php echo e($request->remarks ?: 'This pickup request has been declined or cancelled.'); ?></span>
            </div>
        </div>
    <?php else: ?>
        <div class="d-flex justify-content-between align-items-center position-relative stepper-line-container">
            <div class="stepper-progress-bg"></div>
            <div class="stepper-progress-bar" style="width: <?php echo e(($currentIndex / (count($stageOrder) - 1)) * 100); ?>%;"></div>

            <?php $__currentLoopData = $stageOrder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $isDone = ($idx < $currentIndex);
                    $isActive = ($idx === $currentIndex);
                    $isUpcoming = ($idx > $currentIndex);
                ?>
                <div class="stepper-step text-center <?php echo e($isDone ? 'step-done' : ''); ?> <?php echo e($isActive ? 'step-active' : ''); ?> <?php echo e($isUpcoming ? 'step-upcoming' : ''); ?>">
                    <div class="stepper-circle mx-auto d-flex align-items-center justify-content-center shadow-sm">
                        <?php if($isDone): ?>
                            <i class="fas fa-check small"></i>
                        <?php else: ?>
                            <i class="fas <?php echo e($stages[$key]['icon']); ?> small"></i>
                        <?php endif; ?>
                    </div>
                    <div class="stepper-label mt-1">
                        <span class="d-block fw-semibold"><?php echo e($stages[$key]['label']); ?></span>
                        <?php if($isActive): ?>
                            <span class="badge bg-success bg-opacity-75" style="font-size: .65rem;">Current</span>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
</div>

<style>
    .stepper-line-container {
        position: relative;
        padding: 0 10px;
    }
    .stepper-progress-bg {
        position: absolute;
        top: 18px;
        left: 20px;
        right: 20px;
        height: 3px;
        background: #e2e8f0;
        z-index: 1;
    }
    .stepper-progress-bar {
        position: absolute;
        top: 18px;
        left: 20px;
        height: 3px;
        background: #10b981;
        transition: width .4s ease;
        z-index: 2;
    }
    .stepper-step {
        position: relative;
        z-index: 3;
        flex: 1;
    }
    .stepper-circle {
        width: 36px;
        height: 36px;
        border-radius: 50%;
        background: #fff;
        border: 2px solid #cbd5e1;
        color: #94a3b8;
        font-size: .85rem;
        transition: all .3s ease;
    }
    .step-done .stepper-circle {
        background: #10b981;
        border-color: #10b981;
        color: #fff;
    }
    .step-active .stepper-circle {
        background: #fff;
        border-color: #059669;
        color: #059669;
        box-shadow: 0 0 0 4px rgba(5, 150, 105, 0.2) !important;
    }
    .stepper-label {
        font-size: .75rem;
        color: #64748b;
    }
    .step-active .stepper-label {
        color: #0f172a;
        font-weight: 700 !important;
    }
    .step-done .stepper-label {
        color: #059669;
    }
</style>
<?php /**PATH C:\xampp\htdocs\FoodWasteRescue\resources\views/components/pickup-stepper.blade.php ENDPATH**/ ?>