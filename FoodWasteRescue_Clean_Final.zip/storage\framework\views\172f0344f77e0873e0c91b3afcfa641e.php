<?php $__env->startSection('title', 'Manage NGOs'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
    <li class="breadcrumb-item active">NGOs</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-4">
    <h3 class="fw-bold mb-1">Registered NGO Partners</h3>
    <p class="text-muted small mb-0">Verify NGO certificates, inspect registration documents, and manage platform distribution approvals.</p>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>NGO Name</th>
                        <th>Registration & Certificate</th>
                        <th>Representative</th>
                        <th>Phone / Email</th>
                        <th>City</th>
                        <th>Status</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $ngos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td>
                                <div class="fw-bold text-dark"><?php echo e($n->ngo_name); ?></div>
                                <small class="text-muted">Registered <?php echo e($n->created_at->format('M d, Y')); ?></small>
                            </td>
                            <td>
                                <div><code><?php echo e($n->registration_number); ?></code></div>
                                <?php if($n->fcra_number): ?>
                                    <div class="small text-muted" style="font-size: 11px;">FCRA: <?php echo e($n->fcra_number); ?></div>
                                <?php endif; ?>
                                <?php if($n->registration_document): ?>
                                    <a href="<?php echo e(route('admin.documents.view', ['type' => 'ngo', 'id' => $n->id])); ?>" target="_blank" class="btn btn-xs btn-outline-primary py-0 px-2 mt-1" style="font-size: 11px;">
                                        <i class="fas fa-file-pdf me-1"></i> View Certificate
                                    </a>
                                <?php else: ?>
                                    <span class="badge bg-light text-muted border mt-1" style="font-size: 10px;">No Doc</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($n->owner_name); ?></td>
                            <td>
                                <div class="small"><?php echo e($n->phone); ?></div>
                                <div class="small text-muted"><?php echo e($n->email); ?></div>
                            </td>
                            <td><?php echo e($n->city); ?></td>
                            <td>
                                <span class="badge badge-<?php echo e(strtolower($n->status)); ?>"><?php echo e(ucfirst($n->status)); ?></span>
                                <?php if($n->status === 'rejected' && $n->rejection_reason): ?>
                                    <div class="small text-danger mt-1" style="max-width: 180px; font-size: 11px;" title="<?php echo e($n->rejection_reason); ?>">
                                        <i class="fas fa-info-circle me-1"></i><?php echo e(Str::limit($n->rejection_reason, 45)); ?>

                                    </div>
                                <?php endif; ?>
                            </td>
                            <td class="text-end">
                                <?php if($n->status !== 'active'): ?>
                                    <form action="<?php echo e(route('admin.ngos.approve', $n->id)); ?>" method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="status" value="active">
                                        <button type="submit" class="btn btn-sm btn-success me-1"><i class="fas fa-check me-1"></i> Approve</button>
                                    </form>
                                <?php endif; ?>
                                <?php if($n->status !== 'rejected'): ?>
                                    <button type="button" class="btn btn-sm btn-outline-danger" data-bs-toggle="modal" data-bs-target="#rejectModalNGO<?php echo e($n->id); ?>">
                                        <i class="fas fa-ban me-1"></i> Reject
                                    </button>

                                    <!-- Rejection Modal -->
                                    <div class="modal fade text-start" id="rejectModalNGO<?php echo e($n->id); ?>" tabindex="-1">
                                        <div class="modal-dialog modal-dialog-centered">
                                            <div class="modal-content border-0 shadow">
                                                <div class="modal-header bg-danger text-white">
                                                    <h5 class="modal-title fw-bold"><i class="fas fa-ban me-2"></i> Reject NGO Application</h5>
                                                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                                </div>
                                                <form action="<?php echo e(route('admin.ngos.approve', $n->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="status" value="rejected">
                                                    <div class="modal-body p-4">
                                                        <p class="small text-muted mb-3">Please specify why <strong><?php echo e($n->ngo_name); ?></strong> cannot be approved. The NGO representative will receive this reason in their notification.</p>
                                                        <div class="mb-3">
                                                            <label class="form-label fw-semibold small">Rejection Reason <span class="text-danger">*</span></label>
                                                            <textarea name="rejection_reason" class="form-control" rows="3" placeholder="e.g. Society registration certificate invalid or expired." required></textarea>
                                                        </div>
                                                        <div class="mb-2">
                                                            <label class="form-label fw-semibold small">Internal Admin Notes <span class="text-muted fw-normal">(optional)</span></label>
                                                            <input type="text" name="verification_notes" class="form-control form-control-sm" placeholder="For audit logs">
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer bg-light">
                                                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                                                        <button type="submit" class="btn btn-danger">Confirm Rejection</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="mt-3">
            <?php echo e($ngos->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\FoodWasteRescue\resources\views/admin/ngos.blade.php ENDPATH**/ ?>