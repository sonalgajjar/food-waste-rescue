<?php $__env->startSection('card_width', '640px'); ?>

<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b = $attributes; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\GuestLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<style>
    .role-card { cursor: pointer; border: 2px solid #dee2e6; border-radius: .75rem; padding: 1rem; text-align: center; transition: all .2s ease; }
    .role-card:hover { border-color: #198754; background: #f0fdf4; }
    .role-card.selected { border-color: #198754; background: #d1fae5; color: #065f46; }
    .role-card i { font-size: 1.75rem; display: block; margin-bottom: .4rem; }
    .section-title { font-size: .8rem; font-weight: 700; text-transform: uppercase; letter-spacing: .05em; color: #64748b; border-bottom: 2px solid #e2e8f0; padding-bottom: .4rem; margin-bottom: 1rem; }
</style>

<h4 class="fw-bold text-center mb-1 text-dark">Create Partner Account</h4>
<p class="text-muted small text-center mb-4">Join as a Donor Restaurant or a verified NGO to start rescuing food</p>

<?php if($errors->any()): ?>
    <div class="alert alert-danger mb-4 shadow-sm border-0">
        <div class="fw-bold mb-1"><i class="fas fa-exclamation-circle me-2"></i>Please correct the following:</div>
        <ul class="mb-0 ps-3 small">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<?php
    $selectedRole = old('role', 'restaurant');
?>

<form method="POST" action="<?php echo e(route('register')); ?>" id="registerForm" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>

    
    <div class="mb-4">
        <div class="section-title">Choose Your Role</div>
        <div class="row g-3">
            <div class="col-6">
                <div class="role-card <?php echo e($selectedRole === 'restaurant' ? 'selected' : ''); ?>" id="card-restaurant" onclick="selectRole('restaurant')">
                    <i class="fas fa-utensils text-success"></i>
                    <div class="fw-bold small">Restaurant / Donor</div>
                    <div class="text-muted" style="font-size:.7rem;">Share surplus food</div>
                </div>
            </div>
            <div class="col-6">
                <div class="role-card <?php echo e($selectedRole === 'ngo' ? 'selected' : ''); ?>" id="card-ngo" onclick="selectRole('ngo')">
                    <i class="fas fa-hands-helping text-success"></i>
                    <div class="fw-bold small">NGO / Distributor</div>
                    <div class="text-muted" style="font-size:.7rem;">Collect & distribute food</div>
                </div>
            </div>
        </div>
        <input type="hidden" name="role" id="roleInput" value="<?php echo e($selectedRole); ?>">
    </div>

    
    <div class="section-title">Account Information</div>
    <div class="row g-3 mb-3">
        <div class="col-sm-6">
            <label class="form-label fw-semibold small">Contact Name <span class="text-danger">*</span></label>
            <input type="text" name="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                   value="<?php echo e(old('name')); ?>" placeholder="John Doe" required>
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-sm-6">
            <label class="form-label fw-semibold small">Email Address <span class="text-danger">*</span></label>
            <input type="email" name="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                   value="<?php echo e(old('email')); ?>" placeholder="john@example.com" required>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-sm-6">
            <label class="form-label fw-semibold small">Password <span class="text-danger">*</span></label>
            <input type="password" name="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                   placeholder="Min 8 characters" required>
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-sm-6">
            <label class="form-label fw-semibold small">Confirm Password <span class="text-danger">*</span></label>
            <input type="password" name="password_confirmation" class="form-control" placeholder="Re-enter password" required>
        </div>
        <div class="col-12">
            <label class="form-label fw-semibold small">Phone Number <span class="text-danger">*</span></label>
            <input type="text" name="phone" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                   value="<?php echo e(old('phone')); ?>" placeholder="+91 99999 99999" required>
            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    
    <div id="restaurantFields">
        <div class="section-title">Restaurant Details</div>
        <div class="row g-3 mb-3">
            <div class="col-sm-6">
                <label class="form-label fw-semibold small">Restaurant Name <span class="text-danger">*</span></label>
                <input type="text" id="restaurant_name" name="restaurant_name"
                       class="form-control <?php $__errorArgs = ['restaurant_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                       value="<?php echo e(old('restaurant_name')); ?>" placeholder="e.g. Green Grill" required>
                <?php $__errorArgs = ['restaurant_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-sm-6">
                <label class="form-label fw-semibold small">Owner Name <span class="text-danger">*</span></label>
                <input type="text" id="owner_name_rest" name="owner_name"
                       class="form-control <?php $__errorArgs = ['owner_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                       value="<?php echo e(old('owner_name')); ?>" placeholder="Owner full name" required>
                <?php $__errorArgs = ['owner_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-sm-6">
                <label class="form-label fw-semibold small">FSSAI License No. <span class="text-danger">*</span></label>
                <input type="text" id="license_number" name="license_number"
                       class="form-control <?php $__errorArgs = ['license_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                       value="<?php echo e(old('license_number')); ?>" placeholder="e.g. FSSAI-12345" required>
                <?php $__errorArgs = ['license_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-sm-6">
                <label class="form-label fw-semibold small">License Expiry Date</label>
                <input type="date" name="license_expires_at" class="form-control <?php $__errorArgs = ['license_expires_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                       value="<?php echo e(old('license_expires_at')); ?>" min="<?php echo e(date('Y-m-d')); ?>">
                <?php $__errorArgs = ['license_expires_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-12">
                <label class="form-label fw-semibold small">FSSAI License Document <span class="text-muted fw-normal">(PDF, JPG, PNG - Max 5MB)</span></label>
                <input type="file" name="license_document" class="form-control <?php $__errorArgs = ['license_document'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" accept=".pdf,image/*">
                <?php $__errorArgs = ['license_document'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-sm-6">
                <label class="form-label fw-semibold small">GST Number <span class="text-muted fw-normal">(optional)</span></label>
                <input type="text" name="gst_number" class="form-control"
                       value="<?php echo e(old('gst_number')); ?>" placeholder="e.g. 29AAAAA0000A1Z1">
            </div>
            <div class="col-sm-6">
                <label class="form-label fw-semibold small">Opening Time</label>
                <input type="time" name="opening_time" class="form-control" value="09:00" required>
            </div>
            <div class="col-sm-6">
                <label class="form-label fw-semibold small">Closing Time</label>
                <input type="time" name="closing_time" class="form-control" value="22:00" required>
            </div>
        </div>
    </div>

    
    <div id="ngoFields" class="d-none">
        <div class="section-title">NGO Details</div>
        <div class="row g-3 mb-3">
            <div class="col-sm-6">
                <label class="form-label fw-semibold small">NGO Name <span class="text-danger">*</span></label>
                <input type="text" id="ngo_name" name="ngo_name"
                       class="form-control <?php $__errorArgs = ['ngo_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                       value="<?php echo e(old('ngo_name')); ?>" placeholder="e.g. Hope Alliance">
                <?php $__errorArgs = ['ngo_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-sm-6">
                <label class="form-label fw-semibold small">Registration No. <span class="text-danger">*</span></label>
                <input type="text" id="registration_number" name="registration_number"
                       class="form-control <?php $__errorArgs = ['registration_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                       value="<?php echo e(old('registration_number')); ?>" placeholder="e.g. NGO-98765-IN">
                <?php $__errorArgs = ['registration_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-sm-6">
                <label class="form-label fw-semibold small">FCRA Registration No. <span class="text-muted fw-normal">(optional)</span></label>
                <input type="text" name="fcra_number" class="form-control <?php $__errorArgs = ['fcra_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                       value="<?php echo e(old('fcra_number')); ?>" placeholder="e.g. FCRA-12345678">
                <?php $__errorArgs = ['fcra_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-12">
                <label class="form-label fw-semibold small">NGO Registration Certificate <span class="text-muted fw-normal">(PDF, JPG, PNG - Max 5MB)</span></label>
                <input type="file" name="registration_document" class="form-control <?php $__errorArgs = ['registration_document'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" accept=".pdf,image/*">
                <?php $__errorArgs = ['registration_document'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-12">
                <label class="form-label fw-semibold small">Representative Name <span class="text-danger">*</span></label>
                <input type="text" id="owner_name_ngo" name="owner_name_ngo"
                       class="form-control" placeholder="e.g. Daniel Davis">
            </div>
        </div>
    </div>

    
    <div class="section-title">Address & Location</div>
    <div class="row g-3 mb-4">
        <div class="col-12">
            <label class="form-label fw-semibold small">Street Address <span class="text-danger">*</span></label>
            <input type="text" name="address" class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                   value="<?php echo e(old('address')); ?>" placeholder="123 Hope Lane, Sector 5" required>
            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-sm-4">
            <label class="form-label fw-semibold small">City <span class="text-danger">*</span></label>
            <input type="text" name="city" class="form-control <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                   value="<?php echo e(old('city')); ?>" placeholder="e.g. New Delhi" required>
            <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-sm-4">
            <label class="form-label fw-semibold small">State <span class="text-danger">*</span></label>
            <input type="text" name="state" class="form-control <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                   value="<?php echo e(old('state')); ?>" placeholder="e.g. Delhi" required>
            <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-sm-4">
            <label class="form-label fw-semibold small">Pincode <span class="text-danger">*</span></label>
            <input type="text" name="pincode" class="form-control <?php $__errorArgs = ['pincode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                   value="<?php echo e(old('pincode')); ?>" placeholder="e.g. 110001" required>
            <?php $__errorArgs = ['pincode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-1">
                <label class="form-label fw-semibold small mb-0">GPS Coordinates <span class="text-muted fw-normal">(Optional, for nearby search)</span></label>
                <button type="button" class="btn btn-sm btn-outline-success py-0 px-2" style="font-size: 11px;" onclick="detectLocation()">
                    <i class="fas fa-crosshairs me-1"></i> Detect My Location
                </button>
            </div>
            <div class="row g-2">
                <div class="col-6">
                    <input type="number" step="any" id="latInput" name="latitude" class="form-control form-control-sm" value="<?php echo e(old('latitude')); ?>" placeholder="Latitude (e.g. 28.6139)">
                </div>
                <div class="col-6">
                    <input type="number" step="any" id="lonInput" name="longitude" class="form-control form-control-sm" value="<?php echo e(old('longitude')); ?>" placeholder="Longitude (e.g. 77.2090)">
                </div>
            </div>
            <div id="geoStatus" class="small text-muted mt-1" style="font-size: 11px;"></div>
        </div>

    </div>

    <button type="submit" class="btn btn-success w-100 py-2 fw-bold">
        <i class="fas fa-user-plus me-2"></i> Create Account & Submit for Verification
    </button>

    <div class="text-center mt-3 pt-3 border-top">
        <p class="small text-muted mb-0">Already have an account?
            <a href="<?php echo e(route('login')); ?>" class="text-success fw-bold text-decoration-none">Log In</a>
        </p>
    </div>
</form>

<script>
function selectRole(role) {
    document.getElementById('roleInput').value = role;

    const cardR = document.getElementById('card-restaurant');
    const cardN = document.getElementById('card-ngo');
    const restFields = document.getElementById('restaurantFields');
    const ngoFields  = document.getElementById('ngoFields');

    if (role === 'restaurant') {
        cardR.classList.add('selected');
        cardN.classList.remove('selected');
        restFields.classList.remove('d-none');
        ngoFields.classList.add('d-none');

        document.getElementById('restaurant_name').setAttribute('required', '');
        document.getElementById('license_number').setAttribute('required', '');
        document.getElementById('owner_name_rest').setAttribute('required', '');
        document.getElementById('ngo_name').removeAttribute('required');
        document.getElementById('registration_number').removeAttribute('required');
    } else {
        cardN.classList.add('selected');
        cardR.classList.remove('selected');
        ngoFields.classList.remove('d-none');
        restFields.classList.add('d-none');

        document.getElementById('ngo_name').setAttribute('required', '');
        document.getElementById('registration_number').setAttribute('required', '');
        document.getElementById('restaurant_name').removeAttribute('required');
        document.getElementById('license_number').removeAttribute('required');
        document.getElementById('owner_name_rest').removeAttribute('required');
    }
}

function detectLocation() {
    const status = document.getElementById('geoStatus');
    if (!navigator.geolocation) {
        status.innerHTML = '<span class="text-danger">Geolocation is not supported by your browser.</span>';
        return;
    }

    status.innerHTML = '<span class="text-primary"><i class="fas fa-spinner fa-spin me-1"></i> Detecting current location...</span>';

    navigator.geolocation.getCurrentPosition(
        function(position) {
            document.getElementById('latInput').value = position.coords.latitude.toFixed(6);
            document.getElementById('lonInput').value = position.coords.longitude.toFixed(6);
            status.innerHTML = '<span class="text-success"><i class="fas fa-check-circle me-1"></i> Coordinates detected successfully!</span>';
        },
        function(error) {
            status.innerHTML = '<span class="text-warning">Could not retrieve GPS: ' + error.message + '. You may enter manually or rely on address.</span>';
        },
        { enableHighAccuracy: true, timeout: 8000 }
    );
}

document.addEventListener('DOMContentLoaded', function() {
    selectRole('<?php echo e($selectedRole); ?>');
});
</script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $attributes = $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\FoodWasteRescue\resources\views/auth/register.blade.php ENDPATH**/ ?>