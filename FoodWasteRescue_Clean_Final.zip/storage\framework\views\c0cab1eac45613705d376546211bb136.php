<?php $__env->startSection('title', 'Pickup Chat — ' . ($pickupRequest->foodDonation->food_name ?? 'Donation')); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(auth()->user()->role === 'restaurant' ? route('restaurant.history') : route('ngo.history')); ?>">Pickup History</a></li>
    <li class="breadcrumb-item active">Live Coordination Chat</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-0">
    <div class="row justify-content-center">
        <div class="col-lg-9 col-xl-8">
            <div class="card border-0 shadow-sm rounded-4 overflow-hidden chat-card">
                <!-- Chat Header -->
                <div class="card-header bg-white border-bottom p-3 d-flex justify-content-between align-items-center">
                    <div class="d-flex align-items-center gap-3">
                        <a href="<?php echo e(auth()->user()->role === 'restaurant' ? route('restaurant.history') : route('ngo.history')); ?>" class="btn btn-sm btn-outline-secondary rounded-circle" style="width:34px;height:34px;">
                            <i class="fas fa-arrow-left"></i>
                        </a>
                        <div>
                            <div class="d-flex align-items-center gap-2">
                                <h6 class="mb-0 fw-bold text-dark"><?php echo e($pickupRequest->foodDonation->food_name ?? 'Surplus Food'); ?></h6>
                                <span class="badge bg-success bg-opacity-10 text-success small"><?php echo e(ucfirst($pickupRequest->status)); ?></span>
                            </div>
                            <small class="text-muted">
                                <i class="fas fa-store me-1"></i> <?php echo e($pickupRequest->foodDonation->restaurant->restaurant_name ?? 'Restaurant'); ?>

                                <span class="mx-1">•</span>
                                <i class="fas fa-hands-helping me-1"></i> <?php echo e($pickupRequest->ngo->ngo_name ?? 'NGO'); ?>

                            </small>
                        </div>
                    </div>
                    <div>
                        <?php if($isClosed): ?>
                            <span class="badge bg-secondary px-3 py-2"><i class="fas fa-lock me-1"></i> Closed</span>
                        <?php else: ?>
                            <span class="badge bg-success px-3 py-2"><i class="fas fa-circle text-white me-1" style="font-size: .5rem;"></i> Active Chat</span>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Chat Messages Body -->
                <div class="card-body p-4 chat-body" id="chatMessagesContainer" style="height: 480px; overflow-y: auto; background: #f8fafc;">
                    <?php $__empty_1 = true; $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $isMe = ($msg->user_id === auth()->id());
                        ?>
                        <div class="d-flex mb-3 <?php echo e($isMe ? 'justify-content-end' : 'justify-content-start'); ?>" data-message-id="<?php echo e($msg->id); ?>">
                            <div class="chat-bubble <?php echo e($isMe ? 'bubble-me' : 'bubble-them'); ?> shadow-sm">
                                <?php if(!$isMe): ?>
                                    <div class="chat-sender-name mb-1">
                                        <?php echo e($msg->user->name ?? 'User'); ?>

                                        <span class="badge bg-light text-secondary border ms-1" style="font-size: .6rem;"><?php echo e(ucfirst($msg->user->role ?? '')); ?></span>
                                    </div>
                                <?php endif; ?>
                                <div class="chat-text"><?php echo e($msg->message); ?></div>
                                <div class="chat-time text-end mt-1">
                                    <small><?php echo e($msg->created_at->format('h:i A')); ?></small>
                                    <?php if($isMe): ?>
                                        <i class="fas fa-check-double text-success ms-1" style="font-size: .65rem;"></i>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="text-center py-5 text-muted empty-chat-state" id="emptyChatNotice">
                            <i class="fas fa-comments fa-3x mb-3 text-secondary opacity-50"></i>
                            <h6 class="fw-semibold">No messages yet</h6>
                            <p class="small mb-0">Coordinate pickup arrival, packaging status, or gate instructions directly here.</p>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Chat Input Footer -->
                <div class="card-footer bg-white border-top p-3">
                    <?php if($isClosed): ?>
                        <div class="alert alert-secondary py-2 px-3 mb-0 small text-center rounded-3">
                            <i class="fas fa-info-circle me-1"></i> This pickup has been completed or closed. Chat is preserved in read-only mode.
                        </div>
                    <?php else: ?>
                        <form id="chatForm" class="d-flex gap-2 align-items-center" onsubmit="sendMessage(event)">
                            <?php echo csrf_field(); ?>
                            <input type="text" id="chatInput" name="message" class="form-control rounded-pill px-3 py-2 border-secondary border-opacity-25" placeholder="Type a message (e.g. 'Standing at the front entrance')..." required autocomplete="off">
                            <button type="submit" class="btn btn-success rounded-pill px-4 py-2 text-white shadow-sm" id="sendBtn">
                                <i class="fas fa-paper-plane me-1"></i> Send
                            </button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .chat-bubble {
        max-width: 75%;
        padding: .75rem 1rem;
        border-radius: 1.1rem;
        position: relative;
    }
    .bubble-me {
        background: #059669;
        color: #ffffff;
        border-bottom-right-radius: .25rem;
    }
    .bubble-me .chat-time {
        color: rgba(255, 255, 255, 0.75);
        font-size: .7rem;
    }
    .bubble-them {
        background: #ffffff;
        color: #1e293b;
        border-bottom-left-radius: .25rem;
        border: 1px solid #e2e8f0;
    }
    .bubble-them .chat-time {
        color: #94a3b8;
        font-size: .7rem;
    }
    .chat-sender-name {
        font-size: .75rem;
        font-weight: 700;
        color: #059669;
    }
    .chat-text {
        font-size: .9rem;
        word-break: break-word;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    let lastMessageId = 0;
    const container = document.getElementById('chatMessagesContainer');

    // Scroll to bottom on load
    function scrollToBottom() {
        if (container) {
            container.scrollTop = container.scrollHeight;
        }
    }

    // Determine highest current message ID
    document.querySelectorAll('[data-message-id]').forEach(el => {
        const id = parseInt(el.getAttribute('data-message-id'), 10);
        if (id > lastMessageId) lastMessageId = id;
    });

    scrollToBottom();

    // Send Message via AJAX
    function sendMessage(e) {
        e.preventDefault();
        const input = document.getElementById('chatInput');
        const text = input.value.trim();
        if (!text) return;

        const sendBtn = document.getElementById('sendBtn');
        sendBtn.disabled = true;

        fetch("<?php echo e(route('chat.send', $pickupRequest->id)); ?>", {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                'Accept': 'application/json'
            },
            body: JSON.stringify({ message: text })
        })
        .then(res => res.json())
        .then(data => {
            sendBtn.disabled = false;
            if (data.success && data.message) {
                appendMessage(data.message);
                input.value = '';
                lastMessageId = Math.max(lastMessageId, data.message.id);
            } else if (data.message) {
                alert(data.message);
            }
        })
        .catch(err => {
            sendBtn.disabled = false;
            console.error(err);
        });
    }

    // Append Message Element
    function appendMessage(msg) {
        const emptyNotice = document.getElementById('emptyChatNotice');
        if (emptyNotice) emptyNotice.remove();

        const row = document.createElement('div');
        row.className = `d-flex mb-3 ${msg.is_me ? 'justify-content-end' : 'justify-content-start'}`;
        row.setAttribute('data-message-id', msg.id);

        const bubble = document.createElement('div');
        bubble.className = `chat-bubble ${msg.is_me ? 'bubble-me' : 'bubble-them'} shadow-sm`;

        let senderHtml = '';
        if (!msg.is_me) {
            senderHtml = `<div class="chat-sender-name mb-1">${escapeHtml(msg.user_name)} <span class="badge bg-light text-secondary border ms-1" style="font-size: .6rem;">${escapeHtml(msg.user_role)}</span></div>`;
        }

        const checkmark = msg.is_me ? '<i class="fas fa-check-double text-success ms-1" style="font-size: .65rem;"></i>' : '';

        bubble.innerHTML = `
            ${senderHtml}
            <div class="chat-text">${escapeHtml(msg.message)}</div>
            <div class="chat-time text-end mt-1">
                <small>${msg.created_at}</small> ${checkmark}
            </div>
        `;

        row.appendChild(bubble);
        container.appendChild(row);
        scrollToBottom();
    }

    function escapeHtml(str) {
        return str.replace(/[&<>"']/g, function(m) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[m];
        });
    }

    // Polling for real-time messages (every 3.5s)
    <?php if(!$isClosed): ?>
    setInterval(() => {
        fetch(`<?php echo e(route('chat.poll', $pickupRequest->id)); ?>?last_id=${lastMessageId}`, {
            headers: { 'Accept': 'application/json' }
        })
        .then(res => res.json())
        .then(data => {
            if (data.messages && data.messages.length > 0) {
                data.messages.forEach(msg => {
                    if (msg.id > lastMessageId) {
                        appendMessage(msg);
                        lastMessageId = msg.id;
                    }
                });
            }
        })
        .catch(err => console.log('Poll idle'));
    }, 3500);
    <?php endif; ?>
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\FoodWasteRescue\resources\views/chat/room.blade.php ENDPATH**/ ?>