<?php $__env->startSection('title', 'Manage Food Donations'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
    <li class="breadcrumb-item active">Food Donations</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-4">
    <h3 class="fw-bold mb-1">System-Wide Food Donations</h3>
    <p class="text-muted small mb-0">Monitor all food listings submitted across all registered restaurants.</p>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover align-middle" id="adminDonationsTable">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>Food Item</th>
                        <th>Restaurant</th>
                        <th>Category</th>
                        <th>Quantity</th>
                        <th>Cooked Time</th>
                        <th>Expiry Time</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $donations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td class="fw-bold text-dark"><?php echo e($d->food_name); ?></td>
                            <td><?php echo e($d->restaurant->restaurant_name ?? 'N/A'); ?></td>
                            <td><span class="badge bg-secondary"><?php echo e($d->category); ?></span></td>
                            <td class="fw-semibold"><?php echo e($d->quantity); ?> <?php echo e($d->unit); ?></td>
                            <td class="small text-muted"><?php echo e($d->cooked_time ? $d->cooked_time->format('M d, H:i') : '-'); ?></td>
                            <td class="small text-muted"><?php echo e($d->expiry_time ? $d->expiry_time->format('M d, H:i') : '-'); ?></td>
                            <td><span class="badge badge-<?php echo e(strtolower($d->status)); ?>"><?php echo e(ucfirst($d->status)); ?></span></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="mt-3">
            <?php echo e($donations->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function() {
        var table = $('#adminDonationsTable');
        if (table.length && table.find('tbody tr').length > 0 && table.find('tbody tr td[colspan]').length === 0) {
            table.DataTable({ paging: false, info: false, searching: true });
        }
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\FoodWasteRescue\resources\views/admin/donations.blade.php ENDPATH**/ ?>