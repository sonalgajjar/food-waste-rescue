<?php $__env->startSection('title', 'Manage Contact Messages'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
    <li class="breadcrumb-item active">Contact Messages</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-4">
    <h3 class="fw-bold mb-1">Public Inquiries & Messages</h3>
    <p class="text-muted small mb-0">Review messages submitted via the website contact form.</p>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>Sender Name</th>
                        <th>Email</th>
                        <th>Subject</th>
                        <th>Message Snippet</th>
                        <th>Submitted At</th>
                        <th>Status</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td class="fw-bold text-dark"><?php echo e($c->name); ?></td>
                            <td><a href="mailto:<?php echo e($c->email); ?>" class="text-decoration-none"><?php echo e($c->email); ?></a></td>
                            <td class="fw-semibold"><?php echo e($c->subject); ?></td>
                            <td class="small text-muted" title="<?php echo e($c->message); ?>"><?php echo e(Str::limit($c->message, 50)); ?></td>
                            <td class="small text-muted"><?php echo e($c->created_at ? $c->created_at->format('M d, H:i') : '-'); ?></td>
                            <td><span class="badge bg-<?php echo e($c->status === 'replied' ? 'success' : 'warning'); ?>"><?php echo e(ucfirst($c->status)); ?></span></td>
                            <td class="text-end">
                                <?php if($c->status !== 'replied'): ?>
                                    <form action="<?php echo e(route('admin.contacts.reply', $c->id)); ?>" method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-success">
                                            <i class="fas fa-check me-1"></i> Mark Replied
                                        </button>
                                    </form>
                                <?php else: ?>
                                    <span class="text-muted small"><i class="fas fa-check-double text-success"></i> Handled</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="mt-3">
            <?php echo e($contacts->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\FoodWasteRescue\resources\views/admin/contacts.blade.php ENDPATH**/ ?>