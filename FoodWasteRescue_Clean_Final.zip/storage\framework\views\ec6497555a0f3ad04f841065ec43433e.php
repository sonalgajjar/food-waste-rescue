<?php $__env->startSection('title', 'Manage Reviews & Ratings'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item active">Reviews Moderation</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-2">
    <div>
        <h3 class="fw-bold mb-1">Reviews & Ratings Moderation</h3>
        <p class="text-muted small mb-0">Oversee feedback exchanged between food donor restaurants and partner NGOs.</p>
    </div>
</div>

<?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show border-0 shadow-sm mb-4" role="alert">
        <i class="fas fa-check-circle me-2"></i> <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<div class="card border-0 shadow-sm rounded-4">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Reviewer</th>
                        <th>Reviewed Target</th>
                        <th>Donation Item</th>
                        <th>Rating</th>
                        <th>Written Review</th>
                        <th>Status</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <strong class="text-dark"><?php echo e($rev->reviewer->name ?? 'User'); ?></strong>
                                <span class="badge bg-light text-secondary border d-block mt-1" style="font-size: .65rem; width: fit-content;">
                                    <?php echo e(ucfirst($rev->reviewer_role)); ?>

                                </span>
                            </td>
                            <td>
                                <?php if($rev->reviewer_role === 'restaurant'): ?>
                                    <span class="text-dark fw-semibold"><?php echo e($rev->ngo->ngo_name ?? 'NGO'); ?></span>
                                    <small class="text-muted d-block">(NGO Partner)</small>
                                <?php else: ?>
                                    <span class="text-dark fw-semibold"><?php echo e($rev->restaurant->restaurant_name ?? 'Restaurant'); ?></span>
                                    <small class="text-muted d-block">(Food Donor)</small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <small class="text-dark"><?php echo e($rev->foodDonation->food_name ?? '-'); ?></small>
                            </td>
                            <td>
                                <div class="text-warning">
                                    <?php for($i = 1; $i <= 5; $i++): ?>
                                        <i class="fas fa-star <?php echo e($i <= $rev->rating ? '' : 'text-muted opacity-25'); ?>" style="font-size: .8rem;"></i>
                                    <?php endfor; ?>
                                    <span class="text-dark fw-bold ms-1" style="font-size: .85rem;"><?php echo e($rev->rating); ?>/5</span>
                                </div>
                            </td>
                            <td>
                                <small class="text-muted"><?php echo e($rev->review ?: 'No written comment.'); ?></small>
                            </td>
                            <td>
                                <?php if($rev->status === 'approved'): ?>
                                    <span class="badge bg-success">Visible</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">Hidden</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-end">
                                <form action="<?php echo e(route('admin.reviews.toggle', $rev->id)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-sm <?php echo e($rev->status === 'approved' ? 'btn-outline-danger' : 'btn-outline-success'); ?>" title="<?php echo e($rev->status === 'approved' ? 'Hide Review' : 'Approve & Show'); ?>">
                                        <i class="fas <?php echo e($rev->status === 'approved' ? 'fa-eye-slash' : 'fa-eye'); ?> me-1"></i>
                                        <?php echo e($rev->status === 'approved' ? 'Hide' : 'Show'); ?>

                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center py-5 text-muted">
                                <i class="fas fa-star-half-alt fa-3x mb-3 text-secondary opacity-50 d-block"></i>
                                <h6>No reviews submitted yet</h6>
                                <p class="small mb-0">Two-way ratings and reviews submitted after completed handovers will appear here.</p>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php if($reviews->hasPages()): ?>
        <div class="card-footer bg-white p-3 border-top">
            <?php echo e($reviews->links()); ?>

        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\FoodWasteRescue\resources\views/admin/reviews/index.blade.php ENDPATH**/ ?>