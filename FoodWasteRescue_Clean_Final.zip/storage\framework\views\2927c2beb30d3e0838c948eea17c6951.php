<?php $__env->startSection('title', 'Manage Restaurants'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
    <li class="breadcrumb-item active">Restaurants</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-4">
    <h3 class="fw-bold mb-1">Partner Restaurants & Donors</h3>
    <p class="text-muted small mb-0">Approve new restaurant applications, inspect uploaded FSSAI certificates, and manage platform verification.</p>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>Restaurant</th>
                        <th>Owner</th>
                        <th>License & Documents</th>
                        <th>Phone / Email</th>
                        <th>City</th>
                        <th>Status</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $restaurants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td>
                                <div class="fw-bold text-dark"><?php echo e($r->restaurant_name); ?></div>
                                <small class="text-muted">Registered <?php echo e($r->created_at->format('M d, Y')); ?></small>
                            </td>
                            <td><?php echo e($r->owner_name); ?></td>
                            <td>
                                <div><code><?php echo e($r->license_number ?? 'N/A'); ?></code></div>
                                <?php if($r->license_document): ?>
                                    <a href="<?php echo e(route('admin.documents.view', ['type' => 'restaurant', 'id' => $r->id])); ?>" target="_blank" class="btn btn-xs btn-outline-primary py-0 px-2 mt-1" style="font-size: 11px;">
                                        <i class="fas fa-file-pdf me-1"></i> View License
                                    </a>
                                <?php else: ?>
                                    <span class="badge bg-light text-muted border mt-1" style="font-size: 10px;">No Doc</span>
                                <?php endif; ?>
                                <?php if($r->license_expires_at): ?>
                                    <div class="small text-muted" style="font-size: 11px;">Exp: <?php echo e(\Carbon\Carbon::parse($r->license_expires_at)->format('M Y')); ?></div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="small"><?php echo e($r->phone); ?></div>
                                <div class="small text-muted"><?php echo e($r->email); ?></div>
                            </td>
                            <td><?php echo e($r->city); ?></td>
                            <td>
                                <span class="badge badge-<?php echo e(strtolower($r->status)); ?>"><?php echo e(ucfirst($r->status)); ?></span>
                                <?php if($r->status === 'rejected' && $r->rejection_reason): ?>
                                    <div class="small text-danger mt-1" style="max-width: 180px; font-size: 11px;" title="<?php echo e($r->rejection_reason); ?>">
                                        <i class="fas fa-info-circle me-1"></i><?php echo e(Str::limit($r->rejection_reason, 45)); ?>

                                    </div>
                                <?php endif; ?>
                            </td>
                            <td class="text-end">
                                <?php if($r->status !== 'active'): ?>
                                    <form action="<?php echo e(route('admin.restaurants.approve', $r->id)); ?>" method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="status" value="active">
                                        <button type="submit" class="btn btn-sm btn-success me-1"><i class="fas fa-check me-1"></i> Approve</button>
                                    </form>
                                <?php endif; ?>
                                <?php if($r->status !== 'rejected'): ?>
                                    <button type="button" class="btn btn-sm btn-outline-danger" data-bs-toggle="modal" data-bs-target="#rejectModal<?php echo e($r->id); ?>">
                                        <i class="fas fa-ban me-1"></i> Reject
                                    </button>

                                    <!-- Rejection Modal -->
                                    <div class="modal fade text-start" id="rejectModal<?php echo e($r->id); ?>" tabindex="-1">
                                        <div class="modal-dialog modal-dialog-centered">
                                            <div class="modal-content border-0 shadow">
                                                <div class="modal-header bg-danger text-white">
                                                    <h5 class="modal-title fw-bold"><i class="fas fa-ban me-2"></i> Reject Restaurant Application</h5>
                                                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                                </div>
                                                <form action="<?php echo e(route('admin.restaurants.approve', $r->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="status" value="rejected">
                                                    <div class="modal-body p-4">
                                                        <p class="small text-muted mb-3">Please specify why <strong><?php echo e($r->restaurant_name); ?></strong> cannot be approved. The donor will be notified with this reason.</p>
                                                        <div class="mb-3">
                                                            <label class="form-label fw-semibold small">Rejection Reason <span class="text-danger">*</span></label>
                                                            <textarea name="rejection_reason" class="form-control" rows="3" placeholder="e.g. FSSAI License expired or unreadable document uploaded." required></textarea>
                                                        </div>
                                                        <div class="mb-2">
                                                            <label class="form-label fw-semibold small">Internal Admin Notes <span class="text-muted fw-normal">(optional)</span></label>
                                                            <input type="text" name="verification_notes" class="form-control form-control-sm" placeholder="For audit logs">
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer bg-light">
                                                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                                                        <button type="submit" class="btn btn-danger">Confirm Rejection</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="mt-3">
            <?php echo e($restaurants->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\FoodWasteRescue\resources\views/admin/restaurants.blade.php ENDPATH**/ ?>