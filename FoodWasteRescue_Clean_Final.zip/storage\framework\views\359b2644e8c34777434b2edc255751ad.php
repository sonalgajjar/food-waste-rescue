<?php $__env->startSection('title', 'Manage Users'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
    <li class="breadcrumb-item active">Users</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-4">
    <h3 class="fw-bold mb-1">User Account Governance</h3>
    <p class="text-muted small mb-0">View all registered users, roles, and status controls.</p>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Phone</th>
                        <th>City</th>
                        <th>Status</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td class="fw-bold text-dark"><?php echo e($u->name); ?></td>
                            <td><?php echo e($u->email); ?></td>
                            <td>
                                <?php if($u->role === 'admin'): ?>
                                    <span class="badge bg-danger">Admin</span>
                                <?php elseif($u->role === 'restaurant'): ?>
                                    <span class="badge bg-success">Restaurant</span>
                                <?php else: ?>
                                    <span class="badge bg-info text-dark">NGO</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($u->phone ?? 'N/A'); ?></td>
                            <td><?php echo e($u->city ?? 'N/A'); ?></td>
                            <td><span class="badge badge-<?php echo e(strtolower($u->status)); ?>"><?php echo e(ucfirst($u->status)); ?></span></td>
                            <td class="text-end">
                                <?php if($u->role !== 'admin'): ?>
                                    <form action="<?php echo e(route('admin.users.toggle', $u->id)); ?>" method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-<?php echo e($u->status === 'active' ? 'warning' : 'success'); ?>">
                                            <i class="fas fa-power-off me-1"></i> <?php echo e($u->status === 'active' ? 'Deactivate' : 'Activate'); ?>

                                        </button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="mt-3">
            <?php echo e($users->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\FoodWasteRescue\resources\views/admin/users.blade.php ENDPATH**/ ?>